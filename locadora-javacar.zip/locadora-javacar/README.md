
# Locadora de Carros (Java Puro) — Revisada PF/PJ com DV (99,99% funcional)

Esta versão mantém alta correção e lógica funcional, adicionando **PF/PJ** com validação de **CPF/CNPJ com dígitos verificadores (DV)**, re-prompt robusto de entrada e regras centrais de preço.

## Destaques
- `Cliente` suporta **PF (CPF)** e **PJ (CNPJ)** — um documento por vez.
- `ValidationUtils` valida: CPF/CNPJ **com DV**, email, telefone, placa, datas e ano do veículo.
- `ConsoleInput` tem `readEnum` para evitar categorias inválidas.
- `Services` com checagens de estado consistentes.

## Compilar e executar
```bash
javac -d out $(find . -name "*.java")
java -cp out br.com.locadora.Main
```

## Observações
- Persistência em memória (ArrayList).
- Os DVs de CPF/CNPJ seguem os pesos oficiais; sequências de dígitos repetidos são rejeitadas.
- Ajuste as tarifas em `util/PricingRules.java` conforme necessário.
