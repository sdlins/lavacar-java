
package br.com.locadora.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class ConsoleInput {
    private final Scanner sc;
    private final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE;
    public ConsoleInput(Scanner sc) { this.sc = sc; }

    public String readNonBlank(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = sc.nextLine();
            try {
                ValidationUtils.notBlank(v, "Entrada");
                return v.trim();
            } catch (RuntimeException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
    }
    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = sc.nextLine();
            try { return Integer.parseInt(v); }
            catch (NumberFormatException e) { System.out.println("Erro: informe um número inteiro."); }
        }
    }
    public long readLong(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = sc.nextLine();
            try { return Long.parseLong(v); }
            catch (NumberFormatException e) { System.out.println("Erro: informe um número inteiro longo."); }
        }
    }
    public double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = sc.nextLine();
            try { return Double.parseDouble(v.replace(',', '.')); }
            catch (NumberFormatException e) { System.out.println("Erro: informe um número válido."); }
        }
    }
    public LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = sc.nextLine();
            try { return LocalDate.parse(v, ISO); }
            catch (DateTimeParseException e) { System.out.println("Erro: formato de data inválido. Use AAAA-MM-DD."); }
        }
    }

    public <E extends Enum<E>> E readEnum(String prompt, Class<E> enumType) {
        while (true) {
            System.out.print(prompt);
            String v = sc.nextLine();
            try { return Enum.valueOf(enumType, v.trim().toUpperCase()); }
            catch (IllegalArgumentException e) {
                System.out.println("Valor inválido. Opções: " + String.join(", ", java.util.Arrays.stream(enumType.getEnumConstants()).map(Enum::name).toList()));
            }
        }
    }
}
