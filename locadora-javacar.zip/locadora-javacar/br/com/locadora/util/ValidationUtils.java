
package br.com.locadora.util;

import java.time.LocalDate;
import java.time.Year;
import java.util.regex.Pattern;
import br.com.locadora.exception.ValidationException;

public class ValidationUtils {
    private static final Pattern EMAIL = Pattern.compile("^[^@]+@[^@]+\\.[^@]+$");
    private static final Pattern TELEFONE = Pattern.compile("^\\d{10,13}$");
    private static final Pattern PLACA = Pattern.compile("^[A-Z]{3}-?(?:\\d{4}|\\d[A-J]\\d{2})$");

    private static final Pattern ONLY_DIGITS = Pattern.compile("^\\d+$");

    public static void notBlank(String v, String field) {
        if (v == null || v.trim().isEmpty()) throw new ValidationException(field + " não pode ser vazio.");
    }
    public static void positive(double v, String field) {
        if (v < 0) throw new ValidationException(field + " deve ser >= 0.");
    }
    public static void email(String v) {
        if (!EMAIL.matcher(v).matches()) throw new ValidationException("Email inválido.");
    }
    public static void telefone(String v) {
        if (!TELEFONE.matcher(v).matches()) throw new ValidationException("Telefone inválido (use 10 a 13 dígitos).");
    }
    public static void placa(String v) {
        if (!PLACA.matcher(v.toUpperCase()).matches()) throw new ValidationException("Placa inválida (ex.: ABC-1234).");
    }
    public static void dateOrder(LocalDate inicio, LocalDate fim) {
        if (inicio == null || fim == null) throw new ValidationException("Datas não podem ser nulas.");
        if (!fim.isAfter(inicio)) throw new ValidationException("Data de devolução deve ser após a retirada.");
    }
    public static void notPast(LocalDate d, String field) {
        if (d.isBefore(LocalDate.now())) throw new ValidationException(field + " não pode ser no passado.");
    }
    public static void anoVeiculoValido(int ano) {
        int current = Year.now().getValue();
        if (ano < 1950 || ano > current + 1) throw new ValidationException("Ano inválido. Deve estar entre 1950 e " + (current + 1));
    }

    // ==== CPF/CNPJ com verificação de dígitos (DV) ====
    public static void cpf(String v) {
        if (v == null) throw new ValidationException("CPF não pode ser nulo.");
        String d = digitsOnly(v);
        if (d.length() != 11) throw new ValidationException("CPF inválido (use 11 dígitos).");
        if (allSameDigits(d)) throw new ValidationException("CPF inválido.");
        if (!isCPFValidDV(d)) throw new ValidationException("CPF inválido.");
    }

    public static void cnpj(String v) {
        if (v == null) throw new ValidationException("CNPJ não pode ser nulo.");
        String d = digitsOnly(v);
        if (d.length() != 14) throw new ValidationException("CNPJ inválido (use 14 dígitos).");
        if (allSameDigits(d)) throw new ValidationException("CNPJ inválido.");
        if (!isCNPJValidDV(d)) throw new ValidationException("CNPJ inválido.");
    }

    private static String digitsOnly(String v) {
        String s = v.replaceAll("\\D", "");
        if (!ONLY_DIGITS.matcher(s).matches()) throw new ValidationException("Documento deve conter apenas dígitos.");
        return s;
    }
    private static boolean allSameDigits(String s) {
        char c = s.charAt(0);
        for (int i = 1; i < s.length(); i++) if (s.charAt(i) != c) return false;
        return true;
    }
    private static boolean isCPFValidDV(String cpf) {
        // Primeiro DV
        int sum = 0;
        for (int i = 0, w = 10; i < 9; i++, w--) sum += (cpf.charAt(i) - '0') * w;
        int r = sum % 11; int d1 = (r < 2) ? 0 : 11 - r;
        // Segundo DV
        sum = 0;
        for (int i = 0, w = 11; i < 9; i++, w--) sum += (cpf.charAt(i) - '0') * w;
        sum += d1 * 2;
        r = sum % 11; int d2 = (r < 2) ? 0 : 11 - r;
        return (cpf.charAt(9) - '0') == d1 && (cpf.charAt(10) - '0') == d2;
    }
    private static boolean isCNPJValidDV(String cnpj) {
        int[] w1 = {5,4,3,2,9,8,7,6,5,4,3,2};
        int[] w2 = {6,5,4,3,2,9,8,7,6,5,4,3,2};
        int sum = 0;
        for (int i = 0; i < 12; i++) sum += (cnpj.charAt(i) - '0') * w1[i];
        int r = sum % 11; int d1 = (r < 2) ? 0 : 11 - r;
        sum = 0;
        for (int i = 0; i < 12; i++) sum += (cnpj.charAt(i) - '0') * w2[i];
        sum += d1 * w2[12];
        r = sum % 11; int d2 = (r < 2) ? 0 : 11 - r;
        return (cnpj.charAt(12) - '0') == d1 && (cnpj.charAt(13) - '0') == d2;
    }
}
