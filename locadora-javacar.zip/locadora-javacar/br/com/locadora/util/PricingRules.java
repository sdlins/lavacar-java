
package br.com.locadora.util;

import br.com.locadora.model.enums.CategoriaVeiculo;

import java.math.BigDecimal;

public class PricingRules {
    public static BigDecimal valorDiaria(CategoriaVeiculo categoria) {
        return switch (categoria) {
            case ECONOMICO -> BigDecimal.valueOf(100.0);
            case SUV -> BigDecimal.valueOf(150.0);
            case LUXO -> BigDecimal.valueOf(250.0);
        };
    }
    public static BigDecimal multaAtrasoPorDia() { return BigDecimal.valueOf(50.0); }
}
