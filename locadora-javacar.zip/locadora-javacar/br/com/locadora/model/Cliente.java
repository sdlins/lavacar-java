
package br.com.locadora.model;

import br.com.locadora.model.enums.TipoCliente;
import br.com.locadora.util.ValidationUtils;

public class Cliente {
    private long id;
    private TipoCliente tipo; // PF ou PJ
    private String nome;
    private String cpf;   // PF
    private String cnpj;  // PJ
    private String telefone;
    private String email;

    public Cliente() {}
    public Cliente(long id, TipoCliente tipo, String nome, String doc, String telefone, String email) {
        this.id = id; setTipo(tipo); setNome(nome); setTelefone(telefone); setEmail(email);
        if (tipo == TipoCliente.PESSOA_FISICA) setCpf(doc); else setCnpj(doc);
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public TipoCliente getTipo() { return tipo; }
    public void setTipo(TipoCliente tipo) { this.tipo = tipo; }
    public String getNome() { return nome; }
    public void setNome(String nome) { ValidationUtils.notBlank(nome, this.tipo == TipoCliente.PESSOA_JURIDICA ? "Razão Social" : "Nome"); this.nome = nome; }
    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { ValidationUtils.cpf(cpf); this.cpf = cpf.replaceAll("\\D", ""); this.cnpj = null; this.tipo = TipoCliente.PESSOA_FISICA; }
    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { ValidationUtils.cnpj(cnpj); this.cnpj = cnpj.replaceAll("\\D", ""); this.cpf = null; this.tipo = TipoCliente.PESSOA_JURIDICA; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { ValidationUtils.telefone(telefone); this.telefone = telefone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { ValidationUtils.email(email); this.email = email; }

    public String getDocumento() { return tipo == TipoCliente.PESSOA_FISICA ? cpf : cnpj; }

    @Override public String toString() {
        return "Cliente{" +
               "id=" + id +
               ", tipo=" + tipo +
               ", nome='" + nome + "'" +
               ", documento='" + getDocumento() + "'" +
               ", telefone='" + telefone + "'" +
               ", email='" + email + "'" +
               '}';
    }
}
