
package br.com.locadora.model;

import java.time.LocalDate;
import br.com.locadora.model.enums.StatusLocacao;

public class Locacao {
    private long id;
    private Reserva reserva; // pode ser null
    private Cliente cliente;
    private Veiculo veiculo;
    private LocalDate dataRetiradaEfetiva;
    private LocalDate dataDevolucaoPrevista;
    private double kmRetirada;
    private StatusLocacao status = StatusLocacao.ATIVA;

    public Locacao() {}
    public Locacao(long id, Cliente cliente, Veiculo veiculo, LocalDate retiradaEfetiva, LocalDate devolucaoPrevista, double kmRetirada) {
        this.id = id; this.cliente = cliente; this.veiculo = veiculo;
        this.dataRetiradaEfetiva = retiradaEfetiva; this.dataDevolucaoPrevista = devolucaoPrevista; this.kmRetirada = kmRetirada;
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public Reserva getReserva() { return reserva; }
    public void setReserva(Reserva reserva) { this.reserva = reserva; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public Veiculo getVeiculo() { return veiculo; }
    public void setVeiculo(Veiculo veiculo) { this.veiculo = veiculo; }
    public LocalDate getDataRetiradaEfetiva() { return dataRetiradaEfetiva; }
    public void setDataRetiradaEfetiva(LocalDate dataRetiradaEfetiva) { this.dataRetiradaEfetiva = dataRetiradaEfetiva; }
    public LocalDate getDataDevolucaoPrevista() { return dataDevolucaoPrevista; }
    public void setDataDevolucaoPrevista(LocalDate dataDevolucaoPrevista) { this.dataDevolucaoPrevista = dataDevolucaoPrevista; }
    public double getKmRetirada() { return kmRetirada; }
    public void setKmRetirada(double kmRetirada) { this.kmRetirada = kmRetirada; }
    public StatusLocacao getStatus() { return status; }
    public void setStatus(StatusLocacao status) { this.status = status; }
    @Override public String toString() {
        return "Locacao{" +
               "id=" + id +
               ", cliente=" + (cliente != null ? cliente.getNome() : null) +
               ", veiculo=" + (veiculo != null ? veiculo.getPlaca() : null) +
               ", retiradaEfetiva=" + dataRetiradaEfetiva +
               ", devolucaoPrevista=" + dataDevolucaoPrevista +
               ", kmRetirada=" + kmRetirada +
               ", status=" + status +
               '}';
    }
}
