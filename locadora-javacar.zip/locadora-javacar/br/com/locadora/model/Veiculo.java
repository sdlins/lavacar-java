
package br.com.locadora.model;

import br.com.locadora.model.enums.CategoriaVeiculo;
import br.com.locadora.model.enums.StatusVeiculo;
import br.com.locadora.util.ValidationUtils;

public class Veiculo {
    private long id;
    private String placa;
    private String modelo;
    private int ano;
    private CategoriaVeiculo categoria;
    private StatusVeiculo status = StatusVeiculo.DISPONIVEL;
    private double kmAtual;

    public Veiculo() {}
    public Veiculo(long id, String placa, String modelo, int ano, CategoriaVeiculo categoria, double kmAtual) {
        this.id = id; setPlaca(placa); setModelo(modelo); setAno(ano); setCategoria(categoria); setKmAtual(kmAtual);
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { ValidationUtils.placa(placa); this.placa = placa.toUpperCase(); }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { ValidationUtils.notBlank(modelo, "Modelo"); this.modelo = modelo; }
    public int getAno() { return ano; }
    public void setAno(int ano) { ValidationUtils.anoVeiculoValido(ano); this.ano = ano; }
    public CategoriaVeiculo getCategoria() { return categoria; }
    public void setCategoria(CategoriaVeiculo categoria) { this.categoria = categoria; }
    public StatusVeiculo getStatus() { return status; }
    public void setStatus(StatusVeiculo status) { this.status = status; }
    public double getKmAtual() { return kmAtual; }
    public void setKmAtual(double kmAtual) { ValidationUtils.positive(kmAtual, "KM atual"); this.kmAtual = kmAtual; }
    @Override public String toString() {
        return "Veiculo{" +
               "id=" + id +
               ", placa='" + placa + "'" +
               ", modelo='" + modelo + "'" +
               ", ano=" + ano +
               ", categoria=" + categoria +
               ", status=" + status +
               ", kmAtual=" + kmAtual +
               '}';
    }
}
