
package br.com.locadora.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import br.com.locadora.model.enums.CategoriaVeiculo;
import br.com.locadora.model.enums.StatusReserva;
import br.com.locadora.util.ValidationUtils;

public class Reserva {
    private long id;
    private Cliente cliente;
    private Veiculo veiculo; // opcional
    private CategoriaVeiculo categoriaSolicitada;
    private LocalDate dataRetiradaPrevista;
    private LocalDate dataDevolucaoPrevista;
    private StatusReserva status = StatusReserva.PENDENTE;
    private double valorEstimado;

    public Reserva() {}
    public Reserva(long id, Cliente cliente, CategoriaVeiculo cat, LocalDate retirada, LocalDate devolucao) {
        this.id = id; this.cliente = cliente; this.categoriaSolicitada = cat;
        setDataRetiradaPrevista(retirada); setDataDevolucaoPrevista(devolucao);
        ValidationUtils.dateOrder(retirada, devolucao);
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public Veiculo getVeiculo() { return veiculo; }
    public void setVeiculo(Veiculo veiculo) { this.veiculo = veiculo; }
    public CategoriaVeiculo getCategoriaSolicitada() { return categoriaSolicitada; }
    public void setCategoriaSolicitada(CategoriaVeiculo categoriaSolicitada) { this.categoriaSolicitada = categoriaSolicitada; }
    public LocalDate getDataRetiradaPrevista() { return dataRetiradaPrevista; }
    public void setDataRetiradaPrevista(LocalDate dataRetiradaPrevista) { this.dataRetiradaPrevista = dataRetiradaPrevista; }
    public LocalDate getDataDevolucaoPrevista() { return dataDevolucaoPrevista; }
    public void setDataDevolucaoPrevista(LocalDate dataDevolucaoPrevista) { this.dataDevolucaoPrevista = dataDevolucaoPrevista; }
    public StatusReserva getStatus() { return status; }
    public void setStatus(StatusReserva status) { this.status = status; }
    public double getValorEstimado() { return valorEstimado; }
    public void setValorEstimado(double valorEstimado) { this.valorEstimado = valorEstimado; }
    @Override public String toString() {
        return "Reserva{" +
               "id=" + id +
               ", cliente=" + (cliente != null ? cliente.getNome() : null) +
               ", veiculo=" + (veiculo != null ? veiculo.getPlaca() : null) +
               ", categoriaSolicitada=" + categoriaSolicitada +
               ", retiradaPrevista=" + dataRetiradaPrevista +
               ", devolucaoPrevista=" + dataDevolucaoPrevista +
               ", status=" + status +
               ", valorEstimado=" + valorEstimado +
               '}';
    }

    public void setValorEstimado(BigDecimal multiply) {
    }
}
