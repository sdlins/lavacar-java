
package br.com.locadora.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Devolucao {
    private long id;
    private Locacao locacao;
    private LocalDate dataDevolucaoEfetiva;
    private double kmDevolucao;
    private BigDecimal totalFechamento;

    public Devolucao() {}
    public Devolucao(long id, Locacao locacao, LocalDate dataDev, double kmDev, BigDecimal total) {
        this.id = id; this.locacao = locacao; this.dataDevolucaoEfetiva = dataDev; this.kmDevolucao = kmDev; this.totalFechamento = total;
    }
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public Locacao getLocacao() { return locacao; }
    public void setLocacao(Locacao locacao) { this.locacao = locacao; }
    public LocalDate getDataDevolucaoEfetiva() { return dataDevolucaoEfetiva; }
    public void setDataDevolucaoEfetiva(LocalDate dataDevolucaoEfetiva) { this.dataDevolucaoEfetiva = dataDevolucaoEfetiva; }
    public double getKmDevolucao() { return kmDevolucao; }
    public void setKmDevolucao(double kmDevolucao) { this.kmDevolucao = kmDevolucao; }
    public BigDecimal getTotalFechamento() { return totalFechamento; }
    public void setTotalFechamento(BigDecimal totalFechamento) { this.totalFechamento = totalFechamento; }
    @Override public String toString() {
        return "Devolucao{" +
               "id=" + id +
               ", locacaoId=" + (locacao != null ? locacao.getId() : null) +
               ", dataDevolucaoEfetiva=" + dataDevolucaoEfetiva +
               ", kmDevolucao=" + kmDevolucao +
               ", totalFechamento=" + totalFechamento +
               '}';
    }
}
