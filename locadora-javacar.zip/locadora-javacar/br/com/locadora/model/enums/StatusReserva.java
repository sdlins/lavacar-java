
package br.com.locadora.model.enums;
public enum StatusReserva { PENDENTE, CONFIRMADA, CANCELADA }
