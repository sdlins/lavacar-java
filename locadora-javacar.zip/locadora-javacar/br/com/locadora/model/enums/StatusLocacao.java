
package br.com.locadora.model.enums;
public enum StatusLocacao { ATIVA, ENCERRADA }
