
package br.com.locadora.model.enums;
public enum StatusVeiculo { DISPONIVEL, RESERVADO, LOCADO, MANUTENCAO }
