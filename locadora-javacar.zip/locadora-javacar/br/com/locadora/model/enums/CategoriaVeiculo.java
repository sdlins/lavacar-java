
package br.com.locadora.model.enums;
public enum CategoriaVeiculo { ECONOMICO, SUV, LUXO }
