
package br.com.locadora.repository;

import java.util.*;
import br.com.locadora.model.Locacao;

public class LocacaoRepository {
    private final List<Locacao> locacoes = new ArrayList<>();
    private long seq = 1;

    public Locacao salvar(Locacao l) { l.setId(seq++); locacoes.add(l); return l; }
    public Optional<Locacao> buscarPorId(long id) {
        return locacoes.stream().filter(l -> l.getId() == id).findFirst();
    }
    public List<Locacao> listarTodos() { return new ArrayList<>(locacoes); }
}
