
package br.com.locadora.repository;

import java.util.*;
import br.com.locadora.model.Reserva;

public class ReservaRepository {
    private final List<Reserva> reservas = new ArrayList<>();
    private long seq = 1;

    public Reserva salvar(Reserva r) { r.setId(seq++); reservas.add(r); return r; }
    public Optional<Reserva> buscarPorId(long id) {
        return reservas.stream().filter(r -> r.getId() == id).findFirst();
    }
    public List<Reserva> listarTodos() { return new ArrayList<>(reservas); }
}
