
package br.com.locadora.repository;

import java.util.*;
import br.com.locadora.model.Veiculo;
import br.com.locadora.model.enums.StatusVeiculo;
import br.com.locadora.exception.ConflictException;

public class VeiculoRepository {
    private final List<Veiculo> veiculos = new ArrayList<>();
    private long seq = 1;

    public Veiculo salvar(Veiculo v) {
        for (Veiculo e : veiculos) if (e.getPlaca().equalsIgnoreCase(v.getPlaca()))
            throw new ConflictException("Placa já cadastrada.");
        v.setId(seq++); veiculos.add(v); return v;
    }
    public Optional<Veiculo> buscarPorPlaca(String placa) {
        return veiculos.stream().filter(v -> v.getPlaca().equalsIgnoreCase(placa)).findFirst();
    }
    public List<Veiculo> listarDisponiveis() {
        List<Veiculo> out = new ArrayList<>();
        for (Veiculo v: veiculos) if (v.getStatus() == StatusVeiculo.DISPONIVEL) out.add(v);
        return out;
    }
    public List<Veiculo> listarTodos() { return new ArrayList<>(veiculos); }
}
