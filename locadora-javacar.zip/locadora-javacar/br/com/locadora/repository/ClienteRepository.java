
package br.com.locadora.repository;

import java.util.*;
import br.com.locadora.model.Cliente;
import br.com.locadora.exception.ConflictException;

public class ClienteRepository {
    private final List<Cliente> clientes = new ArrayList<>();
    private long seq = 1;

    public Cliente salvar(Cliente c) {
        String doc = c.getDocumento();
        for (Cliente e : clientes) {
            if (doc != null && doc.equals(e.getDocumento()))
                throw new ConflictException("Documento já cadastrado (CPF/CNPJ).");
        }
        c.setId(seq++);
        clientes.add(c);
        return c;
    }
    public Optional<Cliente> buscarPorId(long id) {
        return clientes.stream().filter(c -> c.getId() == id).findFirst();
    }
    public List<Cliente> listarTodos() { return new ArrayList<>(clientes); }
}
