
package br.com.locadora.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import br.com.locadora.model.*;
import br.com.locadora.model.enums.*;
import br.com.locadora.exception.DomainException;
import br.com.locadora.util.PricingRules;

public class DevolucaoService {
    public Devolucao encerrarLocacao(Locacao l, LocalDate dataDevolucaoEfetiva, double kmDevolucao) {
        Veiculo v = l.getVeiculo();
        if (l.getStatus() != StatusLocacao.ATIVA) throw new DomainException("Locação não está ativa.");
        if (dataDevolucaoEfetiva.isBefore(l.getDataRetiradaEfetiva()))
            throw new DomainException("Devolução não pode ser antes da retirada.");
        if (kmDevolucao < l.getKmRetirada()) throw new DomainException("KM de devolução não pode ser menor que KM de retirada.");

        long diariasReais = Math.max(1, ChronoUnit.DAYS.between(l.getDataRetiradaEfetiva(), dataDevolucaoEfetiva));
        long atraso = Math.max(0, ChronoUnit.DAYS.between(l.getDataDevolucaoPrevista(), dataDevolucaoEfetiva));

        BigDecimal valorDiaria = PricingRules.valorDiaria(v.getCategoria());
        BigDecimal multaAtraso = BigDecimal.valueOf(atraso).multiply(PricingRules.multaAtrasoPorDia());
        BigDecimal total = BigDecimal.valueOf(diariasReais).multiply(valorDiaria).multiply(multaAtraso);


        Devolucao d = new Devolucao(0, l, dataDevolucaoEfetiva, kmDevolucao, total);

        l.setStatus(StatusLocacao.ENCERRADA);
        v.setKmAtual(kmDevolucao);
        v.setStatus(StatusVeiculo.DISPONIVEL);

        return d;
    }
}
