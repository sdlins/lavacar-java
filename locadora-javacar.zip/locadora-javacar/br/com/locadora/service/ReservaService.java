
package br.com.locadora.service;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.time.LocalDate;
import br.com.locadora.model.*;
import br.com.locadora.model.enums.*;
import br.com.locadora.repository.*;
import br.com.locadora.util.ValidationUtils;
import br.com.locadora.util.PricingRules;

public class ReservaService {
    private final ReservaRepository reservaRepo;

    public ReservaService(ReservaRepository rr) {
        this.reservaRepo = rr;
    }

    public Reserva criarReserva(Cliente cliente, CategoriaVeiculo categoria, LocalDate retirada, LocalDate devolucao) {
        ValidationUtils.notPast(retirada, "Data de retirada");
        ValidationUtils.dateOrder(retirada, devolucao);
        Reserva r = new Reserva(0, cliente, categoria, retirada, devolucao);
        long diarias = Math.max(1, ChronoUnit.DAYS.between(retirada, devolucao));
        BigDecimal valorDiaria = PricingRules.valorDiaria(categoria);
        r.setValorEstimado(BigDecimal.valueOf(diarias).multiply(valorDiaria));
        return reservaRepo.salvar(r);
    }

    public boolean confirmarReserva(Reserva r, Veiculo v) {
        if (r.getStatus() == StatusReserva.CANCELADA) return false;
        if (v.getStatus() != StatusVeiculo.DISPONIVEL) return false;
        r.setVeiculo(v);
        r.setStatus(StatusReserva.CONFIRMADA);
        v.setStatus(StatusVeiculo.RESERVADO);
        return true;
    }
}
