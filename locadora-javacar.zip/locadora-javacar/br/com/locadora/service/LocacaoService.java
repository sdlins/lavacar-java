
package br.com.locadora.service;

import br.com.locadora.model.*;
import br.com.locadora.model.enums.*;
import br.com.locadora.exception.DomainException;
import br.com.locadora.repository.*;

public class LocacaoService {
    private final LocacaoRepository locacaoRepo;

    public LocacaoService(LocacaoRepository lr) { this.locacaoRepo = lr; }

    public Locacao efetivarRetirada(Reserva reserva, double kmRetirada) {
        Veiculo v = reserva.getVeiculo();
        if (v == null) throw new DomainException("Reserva sem veículo confirmado.");
        if (reserva.getStatus() != StatusReserva.CONFIRMADA) throw new DomainException("Reserva não está confirmada.");
        if (v.getStatus() == StatusVeiculo.MANUTENCAO) throw new DomainException("Veículo em manutenção.");
        if (v.getStatus() == StatusVeiculo.LOCADO) throw new DomainException("Veículo já está locado.");
        if (kmRetirada < 0) throw new DomainException("KM de retirada inválido.");
        v.setStatus(StatusVeiculo.LOCADO);

        Locacao l = new Locacao(0, reserva.getCliente(), v,
                reserva.getDataRetiradaPrevista(),
                reserva.getDataDevolucaoPrevista(),
                kmRetirada);
        l.setReserva(reserva);
        return locacaoRepo.salvar(l);
    }
}
