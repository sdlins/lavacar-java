
package br.com.locadora.exception;
public class ValidationException extends DomainException {
    public ValidationException(String message) { super(message); }
}
