
package br.com.locadora;

import java.time.LocalDate;
import java.util.Scanner;

import br.com.locadora.model.*;
import br.com.locadora.model.enums.*;
import br.com.locadora.repository.*;
import br.com.locadora.service.*;
import br.com.locadora.util.*;
import br.com.locadora.exception.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ConsoleInput input = new ConsoleInput(sc);

        // Repositórios
        ClienteRepository clienteRepo = new ClienteRepository();
        VeiculoRepository veiculoRepo = new VeiculoRepository();
        ReservaRepository reservaRepo = new ReservaRepository();
        LocacaoRepository locacaoRepo = new LocacaoRepository();

        // Serviços
        ReservaService reservaService = new ReservaService(reservaRepo);
        LocacaoService locacaoService = new LocacaoService(locacaoRepo);
        DevolucaoService devolucaoService = new DevolucaoService();

        // Dados de exemplo
        try {
            clienteRepo.salvar(new Cliente(0, TipoCliente.PESSOA_FISICA, "João Silva", "12345678909", "6199999999", "joao@exemplo.com"));
            clienteRepo.salvar(new Cliente(0, TipoCliente.PESSOA_JURIDICA, "ACME Ltda", "11444777000161", "6133333333", "contato@acme.com"));
            veiculoRepo.salvar(new Veiculo(0, "ABC-1234", "Gol 1.0", 2018, CategoriaVeiculo.ECONOMICO, 45000));
        } catch (DomainException e) { System.out.println("Erro ao carregar dados de exemplo: " + e.getMessage()); }

        int opc = -1;
        do {
            System.out.println("\n=== LOCADORA JAVACAR ===\n");
            System.out.println("1) Cadastrar Cliente (PF/PJ)");
            System.out.println("2) Cadastrar Veículo");
            System.out.println("3) Criar Reserva");
            System.out.println("4) Confirmar Reserva (associar veículo)");
            System.out.println("5) Efetivar Locação");
            System.out.println("6) Registrar Devolução");
            System.out.println("7) Listar Clientes");
            System.out.println("8) Listar Veículos");
            System.out.println("9) Listar Reservas");
            System.out.println("10) Listar Locações");
            System.out.println("0) Sair");
            String in = input.readNonBlank("Opção: ");
            try { opc = Integer.parseInt(in); } catch (NumberFormatException e) { System.out.println("Informe um número."); continue; }

            try {
                switch (opc) {
                    case 1 -> {
                        String tipoStr = input.readNonBlank("Tipo (PF/PJ): ");
                        TipoCliente tipo;
                        if (tipoStr.equalsIgnoreCase("PF")) tipo = TipoCliente.PESSOA_FISICA;
                        else if (tipoStr.equalsIgnoreCase("PJ")) tipo = TipoCliente.PESSOA_JURIDICA;
                        else { System.out.println("\nTipo inválido (use PF ou PJ)."); break; }

                        String nome = input.readNonBlank(tipo == TipoCliente.PESSOA_FISICA ? "Nome: " : "Razão Social: ");
                        String doc = input.readNonBlank(tipo == TipoCliente.PESSOA_FISICA ? "CPF (somente dígitos): " : "CNPJ (somente dígitos): ");
                        String tel = input.readNonBlank("Telefone (10-13 dígitos): ");
                        String email = input.readNonBlank("Email: ");
                        Cliente c = clienteRepo.salvar(new Cliente(0, tipo, nome, doc, tel, email));
                        System.out.println("\nCliente cadastrado: " + c);
                    }
                    case 2 -> {
                        String placa = input.readNonBlank("Placa (ABC-1234 ou ABC-1A23): ");
                        String modelo = input.readNonBlank("Modelo: ");
                        int ano = input.readInt("Ano (1950..atual+1): ");
                        CategoriaVeiculo cat = input.readEnum("Categoria (ECONOMICO/SUV/LUXO): ", CategoriaVeiculo.class);
                        double km = input.readDouble("KM atual: ");
                        Veiculo v = veiculoRepo.salvar(new Veiculo(0, placa, modelo, ano, cat, km));
                        System.out.println("\nVeículo cadastrado: " + v);
                    }
                    case 3 -> {
                        long idCli = input.readLong("ID do Cliente: ");
                        Cliente c = clienteRepo.buscarPorId(idCli).orElseThrow(() -> new NotFoundException("Cliente não encontrado"));
                        CategoriaVeiculo cat = input.readEnum("Categoria (ECONOMICO/SUV/LUXO): ", CategoriaVeiculo.class);
                        LocalDate ret = input.readDate("Retirada (AAAA-MM-DD): ");
                        LocalDate dev = input.readDate("Devolução (AAAA-MM-DD): ");
                        Reserva r = reservaService.criarReserva(c, cat, ret, dev);
                        System.out.println("\nReserva criada: " + r);
                    }
                    case 4 -> {
                        long idRes = input.readLong("ID da Reserva: ");
                        Reserva r = reservaRepo.buscarPorId(idRes).orElseThrow(() -> new NotFoundException("Reserva não encontrada"));
                        String placa = input.readNonBlank("Placa do veículo: ");
                        Veiculo v = veiculoRepo.buscarPorPlaca(placa).orElseThrow(() -> new NotFoundException("Veículo não encontrado"));
                        boolean ok = reservaService.confirmarReserva(r, v);
                        System.out.println(ok ? "\nReserva confirmada." : "Falha: veículo indisponível ou reserva inválida.");
                    }
                    case 5 -> {
                        long idRes = input.readLong("ID da Reserva: ");
                        Reserva r = reservaRepo.buscarPorId(idRes).orElseThrow(() -> new NotFoundException("Reserva não encontrada"));
                        double km = input.readDouble("KM retirada: ");
                        Locacao l = locacaoService.efetivarRetirada(r, km);
                        System.out.println("\nLocação ativa: " + l);
                    }
                    case 6 -> {
                        long idLoc = input.readLong("ID da Locação: ");
                        Locacao l = locacaoRepo.buscarPorId(idLoc).orElseThrow(() -> new NotFoundException("Locação não encontrada"));
                        LocalDate d = input.readDate("Devolução efetiva (AAAA-MM-DD): ");
                        double kmDev = input.readDouble("KM devolução: ");
                        Devolucao dev = devolucaoService.encerrarLocacao(l, d, kmDev);
                        System.out.println("\nDevolução registrada: " + dev);
                        System.out.printf("\nTotal a pagar: R$ %.2f%n", dev.getTotalFechamento());
                    }
                    case 7 -> clienteRepo.listarTodos().forEach(System.out::println);
                    case 8 -> veiculoRepo.listarTodos().forEach(System.out::println);
                    case 9 -> reservaRepo.listarTodos().forEach(System.out::println);
                    case 10 -> locacaoRepo.listarTodos().forEach(System.out::println);
                    case 0 -> System.out.println("Encerrando...");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (ValidationException | ConflictException | NotFoundException e) {
                System.out.println("Erro: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Entrada inválida: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Erro inesperado: " + e.getMessage());
            }
        } while (opc != 0);

        sc.close();
        System.out.println("Encerrado.");
    }
}
